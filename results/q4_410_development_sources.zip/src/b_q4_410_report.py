"""Validate complete paired Q4 evidence and write a reproducible report."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import random
import statistics


def metrics(rows):
    times = sorted(r['mean_clear_time_s'] for r in rows)
    cleared = sum(r['cleared'] for r in rows)
    return dict(episodes=len(rows), cleared=cleared,
                total=sum(r['total_jammers'] for r in rows),
                full_clear=sum(r['cleared']==r['total_jammers'] for r in rows),
                mean_s=statistics.mean(times), median_s=statistics.median(times),
                pooled_s=sum(r['total_virtual_time_s'] for r in rows)/cleared,
                p95_s=times[min(len(times)-1, int(.95*(len(times)-1)))],
                worst_s=max(times), under_410=sum(t<=410 for t in times),
                move_m=statistics.mean(r['move_distance_m'] for r in rows),
                measures=statistics.mean(r['measure_calls'] for r in rows),
                clears=statistics.mean(r['clear_calls'] for r in rows),
                tail_s=statistics.mean(r['tail_s'] for r in rows),
                max_wall_s=max(r['wall_s'] for r in rows))


def paired(rows):
    groups = {}
    for row in rows:
        if row.get('error') or row.get('mean_clear_time_s') is None:
            raise ValueError('Errors or undefined episode metrics must be investigated')
        key = (row['seed'], row['count'], row['directional'])
        pair = groups.setdefault(key, {})
        if row['variant'] in pair:
            raise ValueError(f'Duplicate episode arm: {key}')
        pair[row['variant']] = row
    if any(set(p) != {'baseline','candidate'} for p in groups.values()):
        raise ValueError('Every case must have exactly baseline and candidate arms')
    if any(p['baseline']['total_jammers'] != p['candidate']['total_jammers']
           for p in groups.values()):
        raise ValueError('Unpaired source populations')
    return groups


def summarize(rows):
    pairs = paired(rows)
    base = metrics([p['baseline'] for p in pairs.values()])
    cand = metrics([p['candidate'] for p in pairs.values()])
    losses = [dict(seed=k[0], count=k[1], directional=k[2],
                   baseline=p['baseline']['cleared'], candidate=p['candidate']['cleared'])
              for k,p in pairs.items() if p['candidate']['cleared']<p['baseline']['cleared']]
    by_seed = {}
    for k,p in pairs.items():
        by_seed.setdefault(k[0], []).append(p['candidate']['mean_clear_time_s']-
                                          p['baseline']['mean_clear_time_s'])
    rng = random.Random(410)
    keys = sorted(by_seed)
    samples = sorted(statistics.mean(d for s in rng.choices(keys,k=len(keys))
                                    for d in by_seed[s]) for _ in range(4000))
    return dict(baseline=base, candidate=cand,
                mean_reduction_pct=100*(1-cand['mean_s']/base['mean_s']),
                pooled_reduction_pct=100*(1-cand['pooled_s']/base['pooled_s']),
                paired_time_delta_ci95_s=[samples[100],samples[3899]],
                candidate_clear_regressions=losses,
                paired_time_wins=sum(p['candidate']['mean_clear_time_s']<
                                     p['baseline']['mean_clear_time_s'] for p in pairs.values()))


def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument('inputs',nargs='+')
    ap.add_argument('--out',default='results/q4_410_final_summary.json')
    args=ap.parse_args()
    rows=[]
    evidence=[]
    for name in args.inputs:
        data=json.loads(Path(name).read_text(encoding='utf-8'))
        if not data['source_unchanged']:
            raise ValueError(f'Source changed during {name}')
        if data['completed_records'] != data['plan']['expected_records']:
            raise ValueError(f'Incomplete planned evaluation: {name}')
        if len(data['records']) != data['completed_records']:
            raise ValueError(f'Incorrect record count: {name}')
        rows.extend(data['records'])
        evidence.append(dict(path=name,plan=data['plan']))
    result=summarize(rows)
    result['scenarios']={f'{n}:{d}':summarize([r for r in rows
                                           if (r['count'],r['directional'])==(n,d)])
                         for n,d in sorted({(r['count'],r['directional']) for r in rows})}
    result['evidence']=evidence
    Path(args.out).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('evidence','scenarios')},indent=2))


if __name__=='__main__':
    main()
